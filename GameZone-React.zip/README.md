# GameZone
A simple gaming website with login and leaderboard.